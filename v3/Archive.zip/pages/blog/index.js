import React from "react";
import Butter from "buttercms";
import Link from "next/link";
import moment from "moment";
import Layout from "../../components/Layout";

const butter = Butter("58db10ebc2dbc8562691a0f274b9e8c1f513f1ef");

const Card = props => {
  const { data } = props;
  return (
    <React.Fragment>
      <div className="container">
        <div className="left">
          <div className="title">
            <Link as={`/blog/${data.slug}`} href={`/article?slug=${data.slug}`}>
              <a className="link">{data.title}</a>
            </Link>
          </div>
          <Link as={`/blog/${data.slug}`} href={`/article?slug=${data.slug}`}>
            <p>{data.summary}</p>
          </Link>
          <div className="meta">
            <span>{moment(data.published).format("MMM Do, YYYY")}</span>
          </div>
        </div>
        <div className="right">
          <Link as={`/blog/${data.slug}`} href={`/article?slug=${data.slug}`}>
            <img className="image" src={data.featured_image} />
          </Link>
        </div>
      </div>
      <style jsx>{`
        .container {
          font-family: "Lato", sans-serif;
          padding-bottom: 2rem;
          border-bottom: 1px solid #ccc;
          margin-block-start: 2rem;
          margin-block-end: 2rem;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        .container:last-of-type {
          border: none;
        }
        .left > p {
          margin-block-start: 0;
          margin-block-end: 0;
          margin-top: 1rem;
          margin-bottom: 1rem;
          font-size: 80%;
          line-height: 1.5;
          color: rgba(0, 0, 0, 0.85);
          cursor: pointer;
        }
        .right {
          margin-left: 2rem;
          margin-right: 2rem;
          height: 5rem;
          width: 8.05rem;
          display: flex;
          justify-content: center;
        }
        .image {
          height: 5rem;
          cursor: pointer;
          display: block;
        }
        .meta {
          font-size: 80%;
          color: rgba(0, 0, 0, 0.54);
          margin-top: 1rem;
        }
        .link {
          font-family: "Lora", serif;
          font-weight: bold;
          text-decoration: none;
          color: black;
        }
      `}</style>
    </React.Fragment>
  );
};

class Blog extends React.Component {
  state = {
    list: null
  };

  static async getInitialProps() {
    let list = null;
    try {
      const res = await butter.post.list({ page: 1, page_size: 10 });
      const payload = res.data;
      list =
        payload &&
        payload.data &&
        payload.data.map(item => ({
          categories: item.categories,
          featured_image: item.featured_image,
          published: item.published,
          summary: item.summary,
          tags: item.tags,
          title: item.title,
          url: item.url,
          slug: item.slug
        }));
    } catch (error) {
      console.error(error);
    }
    return { list };
  }

  render() {
    const { list } = this.props;

    const renderedList = list.map(item => <Card data={item} key={item.slug} />);

    return (
      <Layout>
        <div className="container">
          <div className="container-inner">
            <div className="card-container">{renderedList}</div>
          </div>
        </div>
        <style jsx>{`
          .container-inner {
            max-width: 960px;
            margin: 0 auto;
            padding: 0 1rem;
          }
          .card-container {
            margin-top: 2rem;
          }
        `}</style>
      </Layout>
    );
  }
}

export default Blog;
